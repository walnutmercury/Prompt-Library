import streamlit as st
import pandas as pd
import json
import os
import io
from datetime import date, datetime
from dotenv import load_dotenv

load_dotenv()

st.set_page_config(page_title="Report Viewer", layout="wide")

# ── Demo mode ──────────────────────────────────────────────────────────────────
DEMO_MODE = not all([
    os.getenv("DB2_DSN"),
    os.getenv("DB2_USERNAME"),
    os.getenv("DB2_PASSWORD"),
])

DEMO_DATA = {
    "Healthcare Provider Report": pd.DataFrame({
        "Provider ID":      ["HP001", "HP002", "HP003", "HP004", "HP005"],
        "Provider Name":    ["Sydney Medical", "North Shore Clinic", "Westmead Health", "Bondi GP", "Parramatta Care"],
        "Specialty":        ["Cardiology", "General Practice", "Oncology", "General Practice", "Radiology"],
        "State":            ["NSW", "NSW", "NSW", "NSW", "NSW"],
        "Region":           ["Metro", "Metro", "Metro", "Metro", "Western"],
        "Loan Amount":      [450000, 125000, 780000, 95000, 340000],
        "Approved Amount":  [450000, 120000, 800000, 95000, 350000],
        "Status":           ["Active", "Active", "Settled", "Active", "Active"],
        "Product":          ["Practice Loan", "Equipment Finance", "Practice Loan", "Equipment Finance", "Practice Loan"],
        "Approval Date":    ["2024-03-01", "2024-01-15", "2023-11-20", "2024-02-28", "2024-04-05"],
        "Settlement Date":  ["", "", "2024-01-10", "", ""],
        "Contact Name":     ["Dr. Sarah Lee", "Dr. James Park", "Dr. Amy Chen", "Dr. Mark Wu", "Dr. Lisa Tan"],
        "Email":            ["s.lee@sydmed.com", "j.park@nsc.com", "a.chen@westmead.com", "m.wu@bondigp.com", "l.tan@parcare.com"],
    }),
    "Loan Arrears Summary": pd.DataFrame({
        "Account ID":           ["LA1001", "LA1002", "LA1003", "LA1004"],
        "Client Name":          ["Dr. James Wu", "Dr. Sarah Chen", "Dr. Mark Patel", "Dr. Amy Torres"],
        "Client Type":          ["Individual", "Corporate", "Individual", "Corporate"],
        "Days Overdue":         [15, 32, 7, 61],
        "Amount Owing":         [2400.00, 8750.50, 1100.00, 15600.75],
        "Total Exposure":       [450000, 780000, 125000, 340000],
        "Product":              ["Equipment Finance", "Practice Loan", "Equipment Finance", "Practice Loan"],
        "Risk Band":            ["Low", "Medium", "Low", "High"],
        "Arrears Date":         ["2024-03-31", "2024-03-14", "2024-04-08", "2024-02-14"],
        "Last Payment Date":    ["2024-03-16", "2024-03-01", "2024-04-01", "2024-01-31"],
        "Last Payment Amount":  [1200.00, 3500.00, 550.00, 2000.00],
        "Relationship Manager": ["Tom Harris", "Jane Nguyen", "Tom Harris", "Sarah Kim"],
    }),
    "Monthly Settlements": pd.DataFrame({
        "Month":        ["Jan 2024", "Feb 2024", "Mar 2024", "Apr 2024", "May 2024"],
        "Month Date":   ["2024-01-01", "2024-02-01", "2024-03-01", "2024-04-01", "2024-05-01"],
        "State":        ["NSW", "NSW", "NSW", "NSW", "NSW"],
        "Product":      ["All", "All", "All", "All", "All"],
        "Settlements":  [42, 38, 55, 61, 49],
        "Total Value":  [8_200_000, 7_450_000, 10_900_000, 12_300_000, 9_800_000],
        "Avg Loan Size":[195238, 196053, 198182, 201639, 200000],
        "YoY Change":   ["12%", "8%", "21%", "18%", "14%"],
        "MoM Change":   ["", "-9%", "+45%", "+11%", "-20%"],
    }),
}

DEMO_FORMATS = {
    "Healthcare Provider Report": {"Loan Amount": "currency", "Approved Amount": "currency"},
    "Loan Arrears Summary": {"Amount Owing": "currency", "Total Exposure": "currency",
                              "Last Payment Amount": "currency", "Days Overdue": "integer"},
    "Monthly Settlements": {"Total Value": "currency", "Avg Loan Size": "currency", "Settlements": "integer"},
}

DEMO_FILTERS = {
    "Healthcare Provider Report": [
        {"name": "Specialty", "type": "multiselect", "options": ["Cardiology", "General Practice", "Oncology", "Radiology"]},
        {"name": "Status",    "type": "multiselect", "options": ["Active", "Settled", "Pending"]},
    ],
    "Loan Arrears Summary": [
        {"name": "Risk Band",    "type": "multiselect", "options": ["Low", "Medium", "High"]},
        {"name": "Days Overdue", "type": "numeric"},
    ],
    "Monthly Settlements": [],
}

DEMO_DESCS = {
    "Healthcare Provider Report": "Active and settled provider loans by specialty and state.",
    "Loan Arrears Summary": "Accounts with outstanding overdue amounts by risk band.",
    "Monthly Settlements": "Settlement volume and value trends by month.",
}

ROW_LIMIT_WARNING = 5000
OPERATORS = ["equals", "not equals", "contains", "starts with", "greater than", "less than", "is one of"]

# ── Helpers ────────────────────────────────────────────────────────────────────
def apply_formats(df, formats):
    df = df.copy()
    for col, fmt in (formats or {}).items():
        if col not in df.columns:
            continue
        if fmt == "currency":
            df[col] = pd.to_numeric(df[col], errors="coerce").apply(
                lambda v: f"${v:,.0f}" if pd.notna(v) else "")
        elif fmt == "percent":
            df[col] = pd.to_numeric(df[col], errors="coerce").apply(
                lambda v: f"{v:.1f}%" if pd.notna(v) else "")
        elif fmt == "integer":
            df[col] = pd.to_numeric(df[col], errors="coerce").apply(
                lambda v: f"{int(v):,}" if pd.notna(v) else "")
    return df

def apply_adhoc_filter(df, col, op, val):
    if not val:
        return df
    try:
        s = df[col].astype(str)
        if op == "equals":           return df[s.str.lower() == str(val).lower()]
        elif op == "not equals":     return df[s.str.lower() != str(val).lower()]
        elif op == "contains":       return df[s.str.contains(str(val), case=False, na=False)]
        elif op == "starts with":    return df[s.str.startswith(str(val), na=False)]
        elif op == "greater than":   return df[pd.to_numeric(df[col], errors="coerce") > float(val)]
        elif op == "less than":      return df[pd.to_numeric(df[col], errors="coerce") < float(val)]
        elif op == "is one of":
            items = [v.strip() for v in str(val).split(",") if v.strip()]
            return df[s.str.lower().isin([i.lower() for i in items])]
    except Exception:
        pass
    return df

# ── DB2 connection ─────────────────────────────────────────────────────────────
@st.cache_resource
def get_connection():
    import pyodbc
    return pyodbc.connect(
        f"DSN={os.getenv('DB2_DSN')};"
        f"UID={os.getenv('DB2_USERNAME')};"
        f"PWD={os.getenv('DB2_PASSWORD')};"
    )

def run_query(sql):
    conn = get_connection()
    return pd.read_sql(sql, conn)

def load_reports():
    path = os.path.join(os.path.dirname(__file__), "reports.json")
    if not os.path.exists(path):
        return []
    with open(path) as f:
        data = json.load(f)
    return data.get("reports", [])

def build_prompt_sql(base_sql, filters, filter_values):
    sql = base_sql
    for f in filters:
        token = f.get("token", f":{f['name'].lower().replace(' ', '_')}")
        val = filter_values.get(f["name"])
        if val is None or val == [] or val == "":
            sql = sql.replace(token, "NULL")
            continue
        if f["type"] == "multiselect" and val:
            quoted = ", ".join(f"'{v}'" for v in val)
            sql = sql.replace(token, f"({quoted})")
        elif f["type"] == "date":
            sql = sql.replace(token, f"'{val}'")
        elif f["type"] == "numeric":
            sql = sql.replace(token, str(val))
    return sql

# ── Session state ──────────────────────────────────────────────────────────────
for key, default in [
    ("df_base", None), ("formats", {}), ("adhoc_filters", []),
    ("last_report", None), ("last_run", ""), ("elapsed", 0)
]:
    if key not in st.session_state:
        st.session_state[key] = default

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("📊 Report Viewer")

    if DEMO_MODE:
        st.info("**Demo mode** — sample data only.\nAdd DB2 credentials to `.env` to connect live.", icon="🔌")

    all_report_names = list(DEMO_DATA.keys()) if DEMO_MODE else [r["name"] for r in load_reports()]

    if not all_report_names:
        st.warning("No reports configured.")
        st.stop()

    search = st.text_input("🔍 Search reports", placeholder="Type to filter...")
    filtered_names = [n for n in all_report_names if search.lower() in n.lower()] if search else all_report_names

    if not filtered_names:
        st.warning("No reports match that search.")
        st.stop()

    selected_name = st.selectbox("Select Report", filtered_names)

    if st.session_state.last_report != selected_name:
        st.session_state.df_base = None
        st.session_state.adhoc_filters = []
        st.session_state.last_report = selected_name

    filter_values = {}
    st.markdown("---")
    st.subheader("Filters")

    if DEMO_MODE:
        demo_filters = DEMO_FILTERS.get(selected_name, [])
        for f in demo_filters:
            if f["type"] == "multiselect":
                opts = f["options"]
                all_sel = st.checkbox(f"All {f['name']}", value=True, key=f"all_{f['name']}")
                filter_values[f["name"]] = opts if all_sel else st.multiselect(f["name"], opts, key=f"ms_{f['name']}")
            elif f["type"] == "numeric":
                filter_values[f["name"]] = st.number_input(f["name"], min_value=0, value=0, key=f"n_{f['name']}")
        if not demo_filters:
            st.caption("No filters for this report.")
    else:
        reports = load_reports()
        report = next(r for r in reports if r["name"] == selected_name)
        for f in report.get("filters", []):
            if f["type"] == "multiselect":
                try:
                    opts_df = run_query(f"SELECT DISTINCT {f['column']} FROM {f['table']} ORDER BY {f['column']}")
                    opts = opts_df.iloc[:, 0].astype(str).tolist()
                except Exception as e:
                    st.error(f"Could not load {f['name']} options: {e}")
                    opts = []
                all_sel = st.checkbox(f"All {f['name']}", value=True, key=f"all_{f['name']}")
                filter_values[f["name"]] = opts if all_sel else st.multiselect(f["name"], opts, key=f"ms_{f['name']}")
            elif f["type"] == "date":
                default = date.fromisoformat(f.get("default") or str(date.today()))
                filter_values[f["name"]] = st.date_input(f["name"], value=default, key=f"d_{f['name']}")
            elif f["type"] == "numeric":
                filter_values[f["name"]] = st.number_input(f["name"], value=f.get("default", 0), key=f"n_{f['name']}")

    st.markdown("---")
    run_clicked = st.button("▶ Run Report", use_container_width=True, type="primary")

# ── Main area ──────────────────────────────────────────────────────────────────
st.header(selected_name)

if DEMO_MODE:
    if d := DEMO_DESCS.get(selected_name):
        st.caption(d)
else:
    reports = load_reports()
    report = next(r for r in reports if r["name"] == selected_name)
    if desc := report.get("description"):
        st.caption(desc)

# ── Run base query ─────────────────────────────────────────────────────────────
if run_clicked or (DEMO_MODE and st.session_state.df_base is None):
    last_run = datetime.now().strftime("%-I:%M %p")

    if DEMO_MODE:
        df = DEMO_DATA[selected_name].copy()
        for f in DEMO_FILTERS.get(selected_name, []):
            val = filter_values.get(f["name"])
            if f["type"] == "multiselect" and val and f["name"] in df.columns:
                df = df[df[f["name"]].isin(val)]
            elif f["type"] == "numeric" and val and val > 0 and f["name"] in df.columns:
                df = df[df[f["name"]] >= val]
        st.session_state.df_base = df
        st.session_state.formats = DEMO_FORMATS.get(selected_name, {})
        st.session_state.last_run = last_run
    else:
        if run_clicked:
            try:
                t0 = datetime.now()
                resolved_sql = build_prompt_sql(report["base_sql"], report.get("filters", []), filter_values)
                df = run_query(resolved_sql)
                elapsed = (datetime.now() - t0).total_seconds()
                if report.get("columns"):
                    df.columns = report["columns"][:len(df.columns)]
                st.session_state.df_base = df
                st.session_state.formats = {
                    c.get("name"): c.get("format")
                    for c in report.get("column_formats", []) if c.get("format")
                } if report.get("column_formats") else {}
                st.session_state.last_run = last_run
                st.session_state.elapsed = elapsed
            except Exception as e:
                st.error(f"Query failed: {e}")
                st.stop()

# ── Tabs ───────────────────────────────────────────────────────────────────────
if st.session_state.df_base is not None:
    df_base = st.session_state.df_base
    formats = st.session_state.formats
    all_cols = list(df_base.columns)
    last_run = st.session_state.last_run

    tab_report, tab_selfservice, tab_explore = st.tabs([
        "📋 Report",
        "🔧 Self Service",
        "📊 Explore"
    ])

    # ── TAB 1: Standard report ─────────────────────────────────────────────────
    with tab_report:
        if len(df_base) >= ROW_LIMIT_WARNING and len(df_base) % 1000 == 0:
            st.warning(f"⚠ Results show exactly {len(df_base):,} rows — data may be truncated.")

        col_a, col_b = st.columns([3, 1])
        with col_a:
            label = "demo data" if DEMO_MODE else f"{st.session_state.elapsed:.2f}s"
            st.success(f"{len(df_base):,} rows returned ({label})")
        with col_b:
            st.caption(f"Last run: {last_run}")

        st.dataframe(apply_formats(df_base, formats), use_container_width=True, hide_index=True)

        col1, col2 = st.columns(2)
        with col1:
            csv = df_base.to_csv(index=False).encode("utf-8")
            st.download_button("⬇ Download CSV", csv, f"{selected_name}.csv", "text/csv", use_container_width=True)
        with col2:
            buf = io.BytesIO()
            with pd.ExcelWriter(buf, engine="openpyxl") as w:
                df_base.to_excel(w, index=False, sheet_name="Report")
            st.download_button("⬇ Download Excel", buf.getvalue(), f"{selected_name}.xlsx",
                               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                               use_container_width=True)

    # ── TAB 2: Self service ────────────────────────────────────────────────────
    with tab_selfservice:
        st.caption("Slice the report results without re-running the query. No new data is fetched.")

        ss1, ss2, ss3 = st.columns([3, 1, 1])
        with ss1:
            visible_cols = st.multiselect("Columns to show", options=all_cols, default=all_cols, key="ss_cols")
            if not visible_cols:
                visible_cols = all_cols
        with ss2:
            sort_col = st.selectbox("Sort by", ["— none —"] + all_cols, key="ss_sort_col")
        with ss3:
            sort_dir = st.radio("Direction", ["Ascending", "Descending"], key="ss_sort_dir", horizontal=True)

        st.markdown("---")
        st.markdown("**Ad-hoc filters**")

        btn1, btn2 = st.columns([1, 1])
        with btn1:
            if st.button("＋ Add filter", use_container_width=True):
                st.session_state.adhoc_filters.append({"col": all_cols[0], "op": "equals", "val": ""})
                st.rerun()
        with btn2:
            if st.button("✕ Clear all", use_container_width=True):
                st.session_state.adhoc_filters = []
                st.rerun()

        to_remove = []
        for i, f in enumerate(st.session_state.adhoc_filters):
            c1, c2, c3, c4 = st.columns([2, 2, 3, 0.4])
            with c1:
                f["col"] = st.selectbox("Col", all_cols,
                    index=all_cols.index(f["col"]) if f["col"] in all_cols else 0,
                    key=f"af_col_{i}", label_visibility="collapsed")
            with c2:
                f["op"] = st.selectbox("Op", OPERATORS,
                    index=OPERATORS.index(f["op"]) if f["op"] in OPERATORS else 0,
                    key=f"af_op_{i}", label_visibility="collapsed")
            with c3:
                f["val"] = st.text_input("Val", value=f["val"], key=f"af_val_{i}",
                    placeholder="val1, val2, val3" if f["op"] == "is one of" else "value",
                    label_visibility="collapsed")
            with c4:
                if st.button("🗑", key=f"af_del_{i}"):
                    to_remove.append(i)

        if to_remove:
            st.session_state.adhoc_filters = [f for i, f in enumerate(st.session_state.adhoc_filters) if i not in to_remove]
            st.rerun()

        st.markdown("---")
        result_search = st.text_input("🔍 Search results", placeholder="Pins matching rows to top...", key="ss_search")

        view_df = df_base[visible_cols].copy()
        for f in st.session_state.adhoc_filters:
            if f["col"] in view_df.columns and f["val"]:
                view_df = apply_adhoc_filter(view_df, f["col"], f["op"], f["val"])
        if sort_col != "— none —" and sort_col in view_df.columns:
            try:
                view_df = view_df.sort_values(by=sort_col, ascending=(sort_dir == "Ascending"))
            except Exception:
                pass

        pinned_count = 0
        if result_search:
            mask = view_df.apply(lambda row: row.astype(str).str.contains(result_search, case=False).any(), axis=1)
            matched = view_df[mask]
            unmatched = view_df[~mask]
            pinned_count = len(matched)
            view_df = pd.concat([matched, unmatched], ignore_index=True)

        active_filters = [f for f in st.session_state.adhoc_filters if f["val"]]
        parts = []
        if visible_cols != all_cols: parts.append(f"{len(visible_cols)} of {len(all_cols)} columns")
        if active_filters: parts.append(f"{len(active_filters)} filter{'s' if len(active_filters) > 1 else ''} applied")
        if sort_col != "— none —": parts.append(f"sorted by {sort_col}")
        if pinned_count: parts.append(f"{pinned_count} row{'s' if pinned_count > 1 else ''} pinned")
        if parts:
            st.caption("View: " + " · ".join(parts) + f" · {len(view_df):,} rows")

        st.dataframe(apply_formats(view_df, formats), use_container_width=True, hide_index=True)

        col1, col2 = st.columns(2)
        with col1:
            csv = view_df.to_csv(index=False).encode("utf-8")
            st.download_button("⬇ Download CSV", csv, f"{selected_name} (custom).csv", "text/csv", use_container_width=True)
        with col2:
            buf = io.BytesIO()
            with pd.ExcelWriter(buf, engine="openpyxl") as w:
                view_df.to_excel(w, index=False, sheet_name="Report")
            st.download_button("⬇ Download Excel", buf.getvalue(), f"{selected_name} (custom).xlsx",
                               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                               use_container_width=True)

    # ── TAB 3: Explore (PyGWalker) ─────────────────────────────────────────────
    with tab_explore:
        st.caption(
            "Drag fields to build charts — bar, line, scatter, pie, area, heatmap, box plot, geographic map and more. "
            "Use the Data tab to inspect raw values and types. Charts are session-only and are not saved."
        )

        try:
            from pygwalker.api.streamlit import StreamlitRenderer

            # Privacy: fully offline — no data leaves the network
            try:
                import pygwalker.utils.config as pyg_config
                pyg_config.set_config("privacy", "offline")
            except Exception:
                pass

            # Coerce numeric columns so PyGWalker infers types correctly
            explore_df = df_base.copy()
            for col in explore_df.columns:
                coerced = pd.to_numeric(explore_df[col], errors="coerce")
                if coerced.notna().sum() > len(explore_df) * 0.7:
                    explore_df[col] = coerced

            # Cache renderer keyed to the report data
            # spec_io_mode="r" = read-only, nothing ever saves to disk
            @st.cache_resource
            def get_renderer(report_name: str, run_time: str) -> StreamlitRenderer:
                return StreamlitRenderer(
                    explore_df,
                    spec_io_mode="r",
                    kernel_computation=True,
                    debug=False,
                )

            renderer = get_renderer(selected_name, last_run)

            # Two sub-tabs: visual explorer + data profiler
            pyg_vis, pyg_data = st.tabs(["Visual explorer", "Data profiling"])

            with pyg_vis:
                renderer.explorer(key="pyg_explorer")

            with pyg_data:
                renderer.explorer(default_tab="data", key="pyg_data")

        except ImportError:
            st.warning("PyGWalker is not installed.")
            st.code("pip install pygwalker --upgrade", language="bash")
            st.info("Stop the app, run the command above in your terminal (with venv active), then restart.")

else:
    st.info("Set your filters and click **Run Report**.")
