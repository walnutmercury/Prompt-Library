# App 2 — Report Viewer + Explore

Full report viewer with all App 1 features plus a Power BI-style drag-and-drop chart builder.

## Tabs
- **Report** — run reports with filters, download CSV/Excel
- **Self Service** — slice results: column picker, sort, ad-hoc filters, result search
- **Explore** — drag-and-drop chart builder with 9 chart types, table/grid view with subtotals and grand totals, Count Distinct aggregation. Session-only — nothing saves.

## Setup
```
cd App2
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit .env with your DB2 DSN, username, password
streamlit run app.py
```

## To activate on subsequent runs
```
cd App2
source venv/bin/activate
streamlit run app.py
```

## Chart types available in Explore tab
Bar, Horizontal Bar, Line, Area, Scatter, Pie, Donut, Stacked Bar, Table/Grid

## Aggregations
Sum, Average, Count, Count Distinct, Max, Min

## Table features
Subtotals per group, Grand total — both toggleable
