import streamlit as st
import pandas as pd
import json
import os
import io
from datetime import date, datetime
from dotenv import load_dotenv
import streamlit.components.v1 as components

load_dotenv()

st.set_page_config(page_title="Report Viewer", layout="wide")

DEMO_MODE = not all([
    os.getenv("DB2_DSN"),
    os.getenv("DB2_USERNAME"),
    os.getenv("DB2_PASSWORD"),
])

DEMO_DATA = {
    "Healthcare Provider Report": pd.DataFrame({
        "Provider ID":      ["HP001","HP002","HP003","HP004","HP005"],
        "Provider Name":    ["Sydney Medical","North Shore Clinic","Westmead Health","Bondi GP","Parramatta Care"],
        "Specialty":        ["Cardiology","General Practice","Oncology","General Practice","Radiology"],
        "State":            ["NSW","NSW","NSW","NSW","NSW"],
        "Region":           ["Metro","Metro","Metro","Metro","Western"],
        "Loan Amount":      [450000,125000,780000,95000,340000],
        "Approved Amount":  [450000,120000,800000,95000,350000],
        "Status":           ["Active","Active","Settled","Active","Active"],
        "Product":          ["Practice Loan","Equipment Finance","Practice Loan","Equipment Finance","Practice Loan"],
        "Approval Date":    ["2024-03-01","2024-01-15","2023-11-20","2024-02-28","2024-04-05"],
        "Settlement Date":  ["","","2024-01-10","",""],
        "Contact Name":     ["Dr. Sarah Lee","Dr. James Park","Dr. Amy Chen","Dr. Mark Wu","Dr. Lisa Tan"],
        "Email":            ["s.lee@sydmed.com","j.park@nsc.com","a.chen@westmead.com","m.wu@bondigp.com","l.tan@parcare.com"],
    }),
    "Loan Arrears Summary": pd.DataFrame({
        "Account ID":           ["LA1001","LA1002","LA1003","LA1004"],
        "Client Name":          ["Dr. James Wu","Dr. Sarah Chen","Dr. Mark Patel","Dr. Amy Torres"],
        "Client Type":          ["Individual","Corporate","Individual","Corporate"],
        "Days Overdue":         [15,32,7,61],
        "Amount Owing":         [2400.00,8750.50,1100.00,15600.75],
        "Total Exposure":       [450000,780000,125000,340000],
        "Product":              ["Equipment Finance","Practice Loan","Equipment Finance","Practice Loan"],
        "Risk Band":            ["Low","Medium","Low","High"],
        "Arrears Date":         ["2024-03-31","2024-03-14","2024-04-08","2024-02-14"],
        "Last Payment Date":    ["2024-03-16","2024-03-01","2024-04-01","2024-01-31"],
        "Last Payment Amount":  [1200.00,3500.00,550.00,2000.00],
        "Relationship Manager": ["Tom Harris","Jane Nguyen","Tom Harris","Sarah Kim"],
    }),
    "Monthly Settlements": pd.DataFrame({
        "Month":        ["Jan 2024","Feb 2024","Mar 2024","Apr 2024","May 2024"],
        "Month Date":   ["2024-01-01","2024-02-01","2024-03-01","2024-04-01","2024-05-01"],
        "State":        ["NSW","NSW","NSW","NSW","NSW"],
        "Product":      ["All","All","All","All","All"],
        "Settlements":  [42,38,55,61,49],
        "Total Value":  [8_200_000,7_450_000,10_900_000,12_300_000,9_800_000],
        "Avg Loan Size":[195238,196053,198182,201639,200000],
        "YoY Change":   ["12%","8%","21%","18%","14%"],
        "MoM Change":   ["","-9%","+45%","+11%","-20%"],
    }),
}

DEMO_FORMATS = {
    "Healthcare Provider Report": {"Loan Amount":"currency","Approved Amount":"currency"},
    "Loan Arrears Summary": {"Amount Owing":"currency","Total Exposure":"currency","Last Payment Amount":"currency","Days Overdue":"integer"},
    "Monthly Settlements": {"Total Value":"currency","Avg Loan Size":"currency","Settlements":"integer"},
}

DEMO_FILTERS = {
    "Healthcare Provider Report": [
        {"name":"Specialty","type":"multiselect","options":["Cardiology","General Practice","Oncology","Radiology"]},
        {"name":"Status","type":"multiselect","options":["Active","Settled","Pending"]},
    ],
    "Loan Arrears Summary": [
        {"name":"Risk Band","type":"multiselect","options":["Low","Medium","High"]},
        {"name":"Days Overdue","type":"numeric"},
    ],
    "Monthly Settlements": [],
}

DEMO_DESCS = {
    "Healthcare Provider Report": "Active and settled provider loans by specialty and state.",
    "Loan Arrears Summary": "Accounts with outstanding overdue amounts by risk band.",
    "Monthly Settlements": "Settlement volume and value trends by month.",
}

ROW_LIMIT_WARNING = 5000
OPERATORS = ["equals","not equals","contains","starts with","greater than","less than","is one of"]

def apply_formats(df, formats):
    df = df.copy()
    for col, fmt in (formats or {}).items():
        if col not in df.columns: continue
        if fmt == "currency":
            df[col] = pd.to_numeric(df[col], errors="coerce").apply(lambda v: f"${v:,.0f}" if pd.notna(v) else "")
        elif fmt == "integer":
            df[col] = pd.to_numeric(df[col], errors="coerce").apply(lambda v: f"{int(v):,}" if pd.notna(v) else "")
    return df

def apply_adhoc_filter(df, col, op, val):
    if not val: return df
    try:
        s = df[col].astype(str)
        if op == "equals":         return df[s.str.lower() == str(val).lower()]
        elif op == "not equals":   return df[s.str.lower() != str(val).lower()]
        elif op == "contains":     return df[s.str.contains(str(val), case=False, na=False)]
        elif op == "starts with":  return df[s.str.startswith(str(val), na=False)]
        elif op == "greater than": return df[pd.to_numeric(df[col], errors="coerce") > float(val)]
        elif op == "less than":    return df[pd.to_numeric(df[col], errors="coerce") < float(val)]
        elif op == "is one of":
            items = [v.strip() for v in str(val).split(",") if v.strip()]
            return df[s.str.lower().isin([i.lower() for i in items])]
    except Exception: pass
    return df

@st.cache_resource
def get_connection():
    import pyodbc
    return pyodbc.connect(f"DSN={os.getenv('DB2_DSN')};UID={os.getenv('DB2_USERNAME')};PWD={os.getenv('DB2_PASSWORD')};")

def run_query(sql): return pd.read_sql(sql, get_connection())

def load_reports():
    path = os.path.join(os.path.dirname(__file__), "reports.json")
    if not os.path.exists(path): return []
    with open(path) as f: return json.load(f).get("reports", [])

def build_prompt_sql(base_sql, filters, filter_values):
    sql = base_sql
    for f in filters:
        token = f.get("token", f":{f['name'].lower().replace(' ','_')}")
        val = filter_values.get(f["name"])
        if val is None or val == [] or val == "": sql = sql.replace(token, "NULL"); continue
        if f["type"] == "multiselect" and val:
            sql = sql.replace(token, f"({', '.join(chr(39)+v+chr(39) for v in val)})")
        elif f["type"] == "date": sql = sql.replace(token, f"'{val}'")
        elif f["type"] == "numeric": sql = sql.replace(token, str(val))
    return sql

def build_explore_html(df):
    """Build the Power BI-style chart explorer as a self-contained HTML string."""
    # Numeric columns
    num_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    cat_cols = [c for c in df.columns if c not in num_cols]
    # Serialize data as JSON for the JS
    records = df.head(2000).to_dict(orient="records")
    data_json = json.dumps(records)
    fields_json = json.dumps({"num": num_cols, "cat": cat_cols})

    return f"""<!DOCTYPE html><html><head>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<style>
*{{box-sizing:border-box;margin:0;padding:0;font-family:system-ui,sans-serif;font-size:13px}}
body{{background:#fff;color:#1a1a1a}}
.app{{display:grid;grid-template-columns:160px 1fr 148px;height:680px;border:1px solid #e5e5e5;border-radius:10px;overflow:hidden}}
.fpanel{{border-right:1px solid #e5e5e5;padding:10px;background:#f9f9f9;overflow-y:auto}}
.ptitle{{font-size:10px;font-weight:600;color:#888;text-transform:uppercase;letter-spacing:.06em;margin:8px 0 4px;padding-bottom:4px;border-bottom:1px solid #e5e5e5}}
.pill{{display:flex;align-items:center;gap:5px;padding:5px 8px;border-radius:6px;cursor:grab;background:#fff;border:1px solid #e5e5e5;font-size:12px;margin-bottom:3px;user-select:none}}
.pill:hover{{border-color:#ccc}}.pill:active{{opacity:.6;cursor:grabbing}}
.dot{{width:7px;height:7px;border-radius:50%;flex-shrink:0}}
.dn{{background:#378ADD}}.dc{{background:#1D9E75}}
.workspace{{display:flex;flex-direction:column}}
.shelves{{display:grid;grid-template-columns:1fr 1fr 1fr;border-bottom:1px solid #e5e5e5}}
.shelf{{padding:8px 10px;border-right:1px solid #e5e5e5}}
.shelf:last-child{{border-right:none}}
.slbl{{font-size:10px;font-weight:600;color:#888;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px}}
.dz{{min-height:28px;border:1px dashed #ccc;border-radius:6px;display:flex;flex-wrap:wrap;align-items:center;gap:4px;padding:3px 7px;font-size:11px;color:#999}}
.dz.over{{border-color:#378ADD;background:#EBF4FD}}
.chip{{display:inline-flex;align-items:center;gap:4px;background:#EBF4FD;color:#185FA5;border-radius:20px;padding:2px 8px;font-size:11px;font-weight:500}}
.chip span{{cursor:pointer;opacity:.7;font-size:10px}}.chip span:hover{{opacity:1}}
.cbar{{display:flex;align-items:center;gap:6px;padding:4px 10px;border-bottom:1px solid #e5e5e5;background:#f9f9f9;flex-wrap:wrap}}
.clbl{{font-size:10px;color:#888;text-transform:uppercase;letter-spacing:.04em;white-space:nowrap}}
.apill{{padding:2px 8px;border:1px solid #ddd;border-radius:20px;font-size:10px;cursor:pointer;background:none;color:#666}}
.apill:hover{{background:#f0f0f0}}
.apill.on{{background:#EBF4FD;color:#185FA5;border-color:#B5D4F4}}
.sep{{width:1px;height:16px;background:#e5e5e5;flex-shrink:0}}
.carea{{flex:1;padding:14px;display:flex;align-items:center;justify-content:center;overflow:auto}}
.empty{{text-align:center;color:#999;line-height:2.2}}
.qrow{{display:flex;gap:6px;flex-wrap:wrap;justify-content:center;margin-top:10px}}
.qbtn{{padding:4px 10px;border:1px solid #ddd;border-radius:6px;font-size:11px;cursor:pointer;background:none;color:#666}}
.qbtn:hover{{background:#f5f5f5}}
.cw{{width:100%}}
.gw{{width:100%;overflow:auto}}
table{{width:100%;border-collapse:collapse;font-size:12px}}
th{{background:#f5f5f5;padding:7px 12px;text-align:left;font-weight:600;font-size:11px;color:#666;border-bottom:1px solid #e5e5e5;white-space:nowrap}}
th.nr{{text-align:right}}
td{{padding:6px 12px;border-bottom:1px solid #f0f0f0;white-space:nowrap}}
td.nr{{text-align:right;font-variant-numeric:tabular-nums}}
tr.sub td{{background:#f5f5f5;font-weight:600;font-size:11px;color:#666;border-top:1px solid #e5e5e5}}
tr.grand td{{font-weight:600;border-top:2px solid #ccc}}
tr:hover td{{background:#fafafa}}
tr.sub:hover td,tr.grand:hover td{{background:inherit}}
.vpanel{{border-left:1px solid #e5e5e5;padding:10px;background:#f9f9f9;overflow-y:auto}}
.vgrid{{display:grid;grid-template-columns:repeat(3,1fr);gap:4px}}
.vbtn{{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;padding:7px 4px;border:1px solid #e5e5e5;border-radius:6px;cursor:pointer;background:#fff;color:#888;font-size:9px;text-align:center;user-select:none}}
.vbtn:hover{{border-color:#ccc;background:#f5f5f5}}
.vbtn.on{{border-color:#378ADD;background:#EBF4FD;color:#185FA5}}
.vi{{width:28px;height:22px}}
</style></head><body>
<div class="app">
<div class="fpanel">
<div class="ptitle">Dimensions</div>
{chr(10).join(f'<div class="pill" draggable="true" ondragstart="drag(\'{c}\')"><div class="dot dc"></div>{c}</div>' for c in cat_cols[:8])}
<div class="ptitle">Measures</div>
{chr(10).join(f'<div class="pill" draggable="true" ondragstart="drag(\'{c}\')"><div class="dot dn"></div>{c}</div>' for c in num_cols[:6])}
</div>
<div class="workspace">
<div class="shelves">
<div class="shelf"><div class="slbl">X axis / Group by</div>
<div class="dz" id="dz-x" ondragover="ov(event,'dz-x')" ondragleave="lv('dz-x')" ondrop="dp(event,'x')"><span id="hx" style="font-size:11px">drop field</span></div></div>
<div class="shelf"><div class="slbl">Y axis / Values</div>
<div class="dz" id="dz-y" ondragover="ov(event,'dz-y')" ondragleave="lv('dz-y')" ondrop="dp(event,'y')"><span id="hy" style="font-size:11px">drop field</span></div></div>
<div class="shelf"><div class="slbl">Color / Sub-group</div>
<div class="dz" id="dz-c" ondragover="ov(event,'dz-c')" ondragleave="lv('dz-c')" ondrop="dp(event,'c')"><span id="hc" style="font-size:11px">optional</span></div></div>
</div>
<div class="cbar">
<span class="clbl">Agg</span>
<div id="apills">
<button class="apill on" onclick="sa('sum',this)">Sum</button>
<button class="apill" onclick="sa('avg',this)">Avg</button>
<button class="apill" onclick="sa('count',this)">Count</button>
<button class="apill" onclick="sa('countd',this)">Count distinct</button>
<button class="apill" onclick="sa('max',this)">Max</button>
<button class="apill" onclick="sa('min',this)">Min</button>
</div>
<div class="sep" id="tsep" style="display:none"></div>
<span class="clbl" id="tlbl" style="display:none">Totals</span>
<div id="tpills" style="display:none">
<button class="apill on" id="psub" onclick="to('subtotals',this)">Subtotals</button>
<button class="apill on" id="pgrand" onclick="to('grandtotal',this)">Grand total</button>
</div>
</div>
<div class="carea" id="ca">
<div class="empty" id="empty">Drop fields on the shelves to build a chart or table
<div class="qrow">
<button class="qbtn" onclick="ql('1')">Quick: bar chart</button>
<button class="qbtn" onclick="ql('2')">Quick: grouped</button>
<button class="qbtn" onclick="ql('3')">Quick: table</button>
</div></div>
<div class="cw" id="cw" style="display:none"><canvas id="mc"></canvas></div>
<div class="gw" id="gw" style="display:none"><table id="gt"></table></div>
</div></div>
<div class="vpanel">
<div class="ptitle">Visualisations</div>
<div class="vgrid" id="vgrid"></div>
</div></div>
<script>
const DATA={data_json};
const FIELDS={fields_json};
const COLORS=["#378ADD","#1D9E75","#EF9F27","#D85A30","#7F77DD","#D4537E"];
const CHARTS=[
  {{id:"bar",l:"Bar",i:`<svg class="vi" viewBox="0 0 28 22"><rect x="2" y="8" width="5" height="12" rx="1" fill="currentColor" opacity=".9"/><rect x="9" y="4" width="5" height="16" rx="1" fill="currentColor" opacity=".7"/><rect x="16" y="11" width="5" height="9" rx="1" fill="currentColor" opacity=".5"/><rect x="23" y="6" width="5" height="14" rx="1" fill="currentColor" opacity=".8"/></svg>`}},
  {{id:"bar-h",l:"Bar H",i:`<svg class="vi" viewBox="0 0 28 22"><rect x="2" y="2" width="14" height="4" rx="1" fill="currentColor" opacity=".9"/><rect x="2" y="9" width="22" height="4" rx="1" fill="currentColor" opacity=".7"/><rect x="2" y="16" width="9" height="4" rx="1" fill="currentColor" opacity=".5"/></svg>`}},
  {{id:"line",l:"Line",i:`<svg class="vi" viewBox="0 0 28 22"><polyline points="2,18 8,10 14,14 20,6 26,9" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><circle cx="2" cy="18" r="2" fill="currentColor"/><circle cx="8" cy="10" r="2" fill="currentColor"/><circle cx="14" cy="14" r="2" fill="currentColor"/><circle cx="20" cy="6" r="2" fill="currentColor"/></svg>`}},
  {{id:"area",l:"Area",i:`<svg class="vi" viewBox="0 0 28 22"><path d="M2,18 L8,10 L14,14 L20,6 L26,9 L26,20 L2,20 Z" fill="currentColor" opacity=".3"/><polyline points="2,18 8,10 14,14 20,6 26,9" fill="none" stroke="currentColor" stroke-width="2"/></svg>`}},
  {{id:"scatter",l:"Scatter",i:`<svg class="vi" viewBox="0 0 28 22"><circle cx="6" cy="16" r="2.5" fill="currentColor" opacity=".8"/><circle cx="11" cy="9" r="2.5" fill="currentColor" opacity=".8"/><circle cx="16" cy="13" r="2.5" fill="currentColor" opacity=".8"/><circle cx="20" cy="5" r="2.5" fill="currentColor" opacity=".8"/><circle cx="24" cy="11" r="2.5" fill="currentColor" opacity=".8"/></svg>`}},
  {{id:"pie",l:"Pie",i:`<svg class="vi" viewBox="0 0 28 22"><path d="M14,11 L14,2 A9,9 0 0,1 22,16 Z" fill="#378ADD"/><path d="M14,11 L22,16 A9,9 0 0,1 5,16 Z" fill="#1D9E75"/><path d="M14,11 L5,16 A9,9 0 0,1 14,2 Z" fill="#EF9F27"/></svg>`}},
  {{id:"donut",l:"Donut",i:`<svg class="vi" viewBox="0 0 28 22"><path d="M14,11 L14,3 A8,8 0 0,1 21,15 Z" fill="#378ADD"/><path d="M14,11 L21,15 A8,8 0 0,1 7,15 Z" fill="#1D9E75"/><path d="M14,11 L7,15 A8,8 0 0,1 14,3 Z" fill="#EF9F27"/><circle cx="14" cy="11" r="4" fill="#fff"/></svg>`}},
  {{id:"stacked",l:"Stacked",i:`<svg class="vi" viewBox="0 0 28 22"><rect x="3" y="12" width="6" height="8" rx="1" fill="#378ADD"/><rect x="3" y="7" width="6" height="5" rx="1" fill="#1D9E75"/><rect x="11" y="8" width="6" height="12" rx="1" fill="#378ADD"/><rect x="11" y="4" width="6" height="4" rx="1" fill="#1D9E75"/><rect x="19" y="14" width="6" height="6" rx="1" fill="#378ADD"/><rect x="19" y="10" width="6" height="4" rx="1" fill="#1D9E75"/></svg>`}},
  {{id:"table",l:"Table",i:`<svg class="vi" viewBox="0 0 28 22"><rect x="2" y="2" width="24" height="5" rx="1" fill="currentColor" opacity=".5"/><rect x="2" y="9" width="24" height="4" rx="1" fill="currentColor" opacity=".2"/><rect x="2" y="15" width="24" height="4" rx="1" fill="currentColor" opacity=".3"/><line x1="10" y1="2" x2="10" y2="19" stroke="#fff" stroke-width=".5"/><line x1="18" y1="2" x2="18" y2="19" stroke="#fff" stroke-width=".5"/></svg>`}},
];
let s={{x:null,y:null,c:null}},ct="bar",at="sum",opts={{sub:true,grand:true}},inst=null,drag_f=null;
const vg=document.getElementById("vgrid");
CHARTS.forEach(c=>{{
  const b=document.createElement("div");b.className="vbtn"+(c.id==="bar"?" on":"");b.id="vb-"+c.id;
  b.innerHTML=c.i+`<span>${{c.l}}</span>`;b.onclick=()=>sv(c.id);vg.appendChild(b);
}});
function sv(id){{ct=id;document.querySelectorAll(".vbtn").forEach(b=>b.classList.remove("on"));document.getElementById("vb-"+id).classList.add("on");
  const t=id==="table";["tsep","tlbl","tpills"].forEach(e=>{{document.getElementById(e).style.display=t?"":"none";}});render();}}
function drag(f){{drag_f=f}}
function ov(e,id){{e.preventDefault();document.getElementById(id).classList.add("over")}}
function lv(id){{document.getElementById(id).classList.remove("over")}}
function dp(e,slot){{e.preventDefault();lv("dz-"+slot);if(!drag_f)return;s[slot]=drag_f;
  const dz=document.getElementById("dz-"+slot),h=document.getElementById("h"+slot);
  if(h)h.style.display="none";const old=dz.querySelector(".chip");if(old)old.remove();
  const c=document.createElement("span");c.className="chip";c.innerHTML=drag_f+` <span onclick="cl('${{slot}}')">x</span>`;dz.appendChild(c);render();}}
function cl(slot){{s[slot]=null;const lbs={{x:"drop field",y:"drop field",c:"optional"}};
  document.getElementById("dz-"+slot).innerHTML=`<span id="h${{slot}}" style="font-size:11px">${{lbs[slot]}}</span>`;render();}}
function sa(v,btn){{at=v;document.querySelectorAll("#apills .apill").forEach(b=>b.classList.remove("on"));btn.classList.add("on");render();}}
function to(k,btn){{opts[k]=!opts[k];btn.classList.toggle("on",opts[k]);render();}}
function doAgg(rows,field){{
  if(at==="count")return rows.length;
  if(at==="countd")return new Set(rows.map(r=>r[field])).size;
  const v=rows.map(r=>Number(r[field])||0);if(!v.length)return 0;
  if(at==="sum")return v.reduce((a,b)=>a+b,0);
  if(at==="avg")return v.reduce((a,b)=>a+b,0)/v.length;
  if(at==="max")return Math.max(...v);if(at==="min")return Math.min(...v);
  return v.reduce((a,b)=>a+b,0);}}
function fv(v){{
  if(at==="count"||at==="countd")return Math.round(v).toLocaleString();
  if(FIELDS.num.includes(s.y))return"$"+Math.round(v).toLocaleString();
  return(Math.round(v*10)/10).toLocaleString();}}
function render(){{
  const em=document.getElementById("empty"),cw=document.getElementById("cw"),gw=document.getElementById("gw");
  if(!s.x||!s.y){{em.style.display="block";cw.style.display="none";gw.style.display="none";if(inst){{inst.destroy();inst=null;}}return;}}
  em.style.display="none";
  if(ct==="table"){{cw.style.display="none";gw.style.display="block";renderTable();return;}}
  cw.style.display="block";gw.style.display="none";renderChart();}}
function renderTable(){{
  const labels=[...new Set(DATA.map(r=>String(r[s.x]||"")))].sort();
  const groups=s.c?[...new Set(DATA.map(r=>String(r[s.c]||"")))].sort():null;
  const tbl=document.getElementById("gt");tbl.innerHTML="";
  const thead=tbl.createTHead();const hr=thead.insertRow();
  if(groups){{
    [s.x,s.c,`${{at}} of ${{s.y}}`].forEach((t,i)=>{{const th=document.createElement("th");th.textContent=t;if(i===2)th.className="nr";hr.appendChild(th);}});
    const tb=tbl.createTBody();let grand=0;
    labels.forEach(lbl=>{{
      const lr=DATA.filter(r=>String(r[s.x]||"")===lbl);let sub=0;
      groups.forEach((g,gi)=>{{
        const gr=lr.filter(r=>String(r[s.c]||"")===g);const val=doAgg(gr,s.y);sub+=val;
        const tr=tb.insertRow();
        [gi===0?lbl:"",g,fv(val)].forEach((v,i)=>{{const td=tr.insertCell();td.textContent=v;if(i===2)td.className="nr";}});
      }});
      grand+=sub;
      if(opts.sub&&groups.length>1){{const tr=tb.insertRow();tr.className="sub";
        const t1=tr.insertCell();t1.textContent=lbl+" subtotal";t1.colSpan=2;
        const t2=tr.insertCell();t2.textContent=fv(sub);t2.className="nr";}}
    }});
    if(opts.grand){{const tr=tb.insertRow();tr.className="grand";
      const t1=tr.insertCell();t1.textContent="Grand total";t1.colSpan=2;
      const t2=tr.insertCell();t2.textContent=fv(grand);t2.className="nr";}}
  }}else{{
    [s.x,`${{at}} of ${{s.y}}`].forEach((t,i)=>{{const th=document.createElement("th");th.textContent=t;if(i===1)th.className="nr";hr.appendChild(th);}});
    const tb=tbl.createTBody();let grand=0;
    labels.forEach(lbl=>{{
      const rows=DATA.filter(r=>String(r[s.x]||"")===lbl);const val=doAgg(rows,s.y);grand+=val;
      const tr=tb.insertRow();[lbl,fv(val)].forEach((v,i)=>{{const td=tr.insertCell();td.textContent=v;if(i===1)td.className="nr";}});
    }});
    if(opts.grand){{const tr=tb.insertRow();tr.className="grand";
      const t1=tr.insertCell();t1.textContent="Grand total";
      const t2=tr.insertCell();t2.textContent=at==="avg"?fv(doAgg(DATA,s.y)):fv(grand);t2.className="nr";}}
  }}}}
function renderChart(){{
  if(inst){{inst.destroy();inst=null;}}
  const labels=[...new Set(DATA.map(r=>String(r[s.x]||"")))];
  const isPie=ct==="pie"||ct==="donut",isStacked=ct==="stacked",isArea=ct==="area",isHBar=ct==="bar-h";
  let datasets=[];
  if(s.c&&!isPie){{
    const groups=[...new Set(DATA.map(r=>String(r[s.c]||"")))];
    datasets=groups.map((g,gi)=>({{label:g,data:labels.map(l=>doAgg(DATA.filter(r=>String(r[s.x]||"")===l&&String(r[s.c]||"")===g),s.y)),
      backgroundColor:COLORS[gi%COLORS.length],borderColor:COLORS[gi%COLORS.length],borderWidth:1.5,tension:.3,pointRadius:3,fill:isArea}}));
  }}else{{
    const data=labels.map(l=>doAgg(DATA.filter(r=>String(r[s.x]||"")===l),s.y));
    datasets=[{{label:`${{at}} of ${{s.y}}`,data,backgroundColor:isPie?COLORS.slice(0,labels.length):COLORS[0],
      borderColor:isPie?COLORS.slice(0,labels.length):COLORS[0],borderWidth:1.5,tension:.3,pointRadius:3,fill:isArea}}];
  }}
  const fmt=v=>fv(v);
  inst=new Chart(document.getElementById("mc"),{{
    type:isArea?"line":isPie?"pie":ct==="scatter"?"scatter":"bar",
    data:{{labels,datasets}},
    options:{{responsive:true,indexAxis:isHBar?"y":"x",
      plugins:{{legend:{{display:!!s.c||isPie,labels:{{font:{{size:11}},boxWidth:12}}}},
        tooltip:{{callbacks:{{label:ctx=>fmt(ctx.parsed[isHBar?"x":"y"]??ctx.parsed)}}}}}},
      scales:isPie?{{}}:{{
        x:{{stacked:isStacked,ticks:{{font:{{size:11}}}},grid:{{color:"rgba(0,0,0,.04)"}}}},
        y:{{stacked:isStacked,ticks:{{font:{{size:11}},callback:v=>fmt(v)}},grid:{{color:"rgba(0,0,0,.04)"}}}}
      }},cutout:ct==="donut"?"60%":undefined
    }}
  }});}}
function ql(p){{
  const nc=FIELDS.num[0]||"",cc=FIELDS.cat[0]||"",cc2=FIELDS.cat[1]||"";
  if(p==="1"){{s.x=cc;s.y=nc;s.c=null;ct="bar";}}
  else if(p==="2"){{s.x=cc;s.y=nc;s.c=cc2;ct="stacked";}}
  else{{s.x=cc;s.y=nc;s.c=cc2;ct="table";
    ["tsep","tlbl","tpills"].forEach(e=>document.getElementById(e).style.display="");}}
  document.querySelectorAll(".vbtn").forEach(b=>b.classList.remove("on"));
  document.getElementById("vb-"+ct).classList.add("on");
  ["x","y","c"].forEach(slot=>{{if(s[slot]){{
    const dz=document.getElementById("dz-"+slot),h=document.getElementById("h"+slot);
    if(h)h.style.display="none";const old=dz.querySelector(".chip");if(old)old.remove();
    const c=document.createElement("span");c.className="chip";c.innerHTML=s[slot]+` <span onclick="cl('${{slot}}')">x</span>`;dz.appendChild(c);
  }}}});render();}}
</script></body></html>"""

for key, default in [("df_base",None),("formats",{}),("adhoc_filters",[]),("last_report",None),("last_run",""),("elapsed",0)]:
    if key not in st.session_state: st.session_state[key] = default

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("📊 Report Viewer")
    if DEMO_MODE:
        st.info("**Demo mode** — sample data only.\nAdd DB2 credentials to `.env` to connect live.", icon="🔌")

    all_report_names = list(DEMO_DATA.keys()) if DEMO_MODE else [r["name"] for r in load_reports()]
    if not all_report_names: st.warning("No reports configured."); st.stop()

    search = st.text_input("🔍 Search reports", placeholder="Type to filter...")
    filtered_names = [n for n in all_report_names if search.lower() in n.lower()] if search else all_report_names
    if not filtered_names: st.warning("No reports match that search."); st.stop()

    selected_name = st.selectbox("Select Report", filtered_names)
    if st.session_state.last_report != selected_name:
        st.session_state.df_base = None
        st.session_state.adhoc_filters = []
        st.session_state.last_report = selected_name

    filter_values = {}
    st.markdown("---")
    st.subheader("Filters")

    if DEMO_MODE:
        demo_filters = DEMO_FILTERS.get(selected_name, [])
        for f in demo_filters:
            if f["type"] == "multiselect":
                opts = f["options"]
                all_sel = st.checkbox(f"All {f['name']}", value=True, key=f"all_{f['name']}")
                filter_values[f["name"]] = opts if all_sel else st.multiselect(f["name"], opts, key=f"ms_{f['name']}")
            elif f["type"] == "numeric":
                filter_values[f["name"]] = st.number_input(f["name"], min_value=0, value=0, key=f"n_{f['name']}")
        if not demo_filters: st.caption("No filters for this report.")
    else:
        reports = load_reports()
        report = next(r for r in reports if r["name"] == selected_name)
        for f in report.get("filters", []):
            if f["type"] == "multiselect":
                try:
                    opts_df = run_query(f"SELECT DISTINCT {f['column']} FROM {f['table']} ORDER BY {f['column']}")
                    opts = opts_df.iloc[:, 0].astype(str).tolist()
                except Exception as e:
                    st.error(f"Could not load {f['name']} options: {e}"); opts = []
                all_sel = st.checkbox(f"All {f['name']}", value=True, key=f"all_{f['name']}")
                filter_values[f["name"]] = opts if all_sel else st.multiselect(f["name"], opts, key=f"ms_{f['name']}")
            elif f["type"] == "date":
                default = date.fromisoformat(f.get("default") or str(date.today()))
                filter_values[f["name"]] = st.date_input(f["name"], value=default, key=f"d_{f['name']}")
            elif f["type"] == "numeric":
                filter_values[f["name"]] = st.number_input(f["name"], value=f.get("default", 0), key=f"n_{f['name']}")

    st.markdown("---")
    run_clicked = st.button("▶ Run Report", use_container_width=True, type="primary")

# ── Main ───────────────────────────────────────────────────────────────────────
st.header(selected_name)
if DEMO_MODE:
    if d := DEMO_DESCS.get(selected_name): st.caption(d)
else:
    reports = load_reports()
    report = next(r for r in reports if r["name"] == selected_name)
    if desc := report.get("description"): st.caption(desc)

if run_clicked or (DEMO_MODE and st.session_state.df_base is None):
    last_run = datetime.now().strftime("%-I:%M %p")
    if DEMO_MODE:
        df = DEMO_DATA[selected_name].copy()
        for f in DEMO_FILTERS.get(selected_name, []):
            val = filter_values.get(f["name"])
            if f["type"] == "multiselect" and val and f["name"] in df.columns:
                df = df[df[f["name"]].isin(val)]
            elif f["type"] == "numeric" and val and val > 0 and f["name"] in df.columns:
                df = df[df[f["name"]] >= val]
        st.session_state.df_base = df
        st.session_state.formats = DEMO_FORMATS.get(selected_name, {})
        st.session_state.last_run = last_run
    else:
        if run_clicked:
            try:
                t0 = datetime.now()
                df = run_query(build_prompt_sql(report["base_sql"], report.get("filters",[]), filter_values))
                elapsed = (datetime.now() - t0).total_seconds()
                if report.get("columns"): df.columns = report["columns"][:len(df.columns)]
                st.session_state.df_base = df
                st.session_state.formats = {c.get("name"):c.get("format") for c in report.get("column_formats",[]) if c.get("format")} if report.get("column_formats") else {}
                st.session_state.last_run = last_run
                st.session_state.elapsed = elapsed
            except Exception as e:
                st.error(f"Query failed: {e}"); st.stop()

if st.session_state.df_base is not None:
    df_base = st.session_state.df_base
    formats = st.session_state.formats
    all_cols = list(df_base.columns)
    last_run = st.session_state.last_run

    tab_report, tab_ss, tab_explore = st.tabs(["📋 Report", "🔧 Self Service", "📊 Explore"])

    with tab_report:
        if len(df_base) >= ROW_LIMIT_WARNING and len(df_base) % 1000 == 0:
            st.warning(f"⚠ Results show exactly {len(df_base):,} rows — data may be truncated.")
        col_a, col_b = st.columns([3,1])
        with col_a:
            label = "demo data" if DEMO_MODE else f"{st.session_state.elapsed:.2f}s"
            st.success(f"{len(df_base):,} rows returned ({label})")
        with col_b:
            st.caption(f"Last run: {last_run}")
        st.dataframe(apply_formats(df_base, formats), use_container_width=True, hide_index=True)
        c1, c2 = st.columns(2)
        with c1:
            st.download_button("⬇ Download CSV", df_base.to_csv(index=False).encode("utf-8"), f"{selected_name}.csv", "text/csv", use_container_width=True)
        with c2:
            buf = io.BytesIO()
            with pd.ExcelWriter(buf, engine="openpyxl") as w: df_base.to_excel(w, index=False, sheet_name="Report")
            st.download_button("⬇ Download Excel", buf.getvalue(), f"{selected_name}.xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", use_container_width=True)

    with tab_ss:
        st.caption("Slice results without re-running the query.")
        ss1, ss2, ss3 = st.columns([3,1,1])
        with ss1:
            visible_cols = st.multiselect("Columns to show", options=all_cols, default=all_cols, key="ss_cols")
            if not visible_cols: visible_cols = all_cols
        with ss2:
            sort_col = st.selectbox("Sort by", ["— none —"] + all_cols, key="ss_sort_col")
        with ss3:
            sort_dir = st.radio("Direction", ["Ascending","Descending"], key="ss_sort_dir", horizontal=True)
        st.markdown("---")
        st.markdown("**Ad-hoc filters**")
        b1, b2 = st.columns(2)
        with b1:
            if st.button("＋ Add filter", use_container_width=True):
                st.session_state.adhoc_filters.append({"col":all_cols[0],"op":"equals","val":""}); st.rerun()
        with b2:
            if st.button("✕ Clear all", use_container_width=True):
                st.session_state.adhoc_filters = []; st.rerun()
        to_remove = []
        for i, f in enumerate(st.session_state.adhoc_filters):
            c1,c2,c3,c4 = st.columns([2,2,3,0.4])
            with c1: f["col"] = st.selectbox("Col", all_cols, index=all_cols.index(f["col"]) if f["col"] in all_cols else 0, key=f"af_col_{i}", label_visibility="collapsed")
            with c2: f["op"] = st.selectbox("Op", OPERATORS, index=OPERATORS.index(f["op"]) if f["op"] in OPERATORS else 0, key=f"af_op_{i}", label_visibility="collapsed")
            with c3: f["val"] = st.text_input("Val", value=f["val"], key=f"af_val_{i}", placeholder="val1, val2" if f["op"]=="is one of" else "value", label_visibility="collapsed")
            with c4:
                if st.button("🗑", key=f"af_del_{i}"): to_remove.append(i)
        if to_remove:
            st.session_state.adhoc_filters = [f for i,f in enumerate(st.session_state.adhoc_filters) if i not in to_remove]; st.rerun()
        st.markdown("---")
        result_search = st.text_input("🔍 Search results", placeholder="Pins matching rows to top...", key="ss_search")
        view_df = df_base[visible_cols].copy()
        for f in st.session_state.adhoc_filters:
            if f["col"] in view_df.columns and f["val"]:
                view_df = apply_adhoc_filter(view_df, f["col"], f["op"], f["val"])
        if sort_col != "— none —" and sort_col in view_df.columns:
            try: view_df = view_df.sort_values(by=sort_col, ascending=(sort_dir=="Ascending"))
            except Exception: pass
        pinned = 0
        if result_search:
            mask = view_df.apply(lambda row: row.astype(str).str.contains(result_search, case=False).any(), axis=1)
            view_df = pd.concat([view_df[mask], view_df[~mask]], ignore_index=True)
            pinned = mask.sum()
        parts = []
        if visible_cols != all_cols: parts.append(f"{len(visible_cols)} of {len(all_cols)} columns")
        active_f = [f for f in st.session_state.adhoc_filters if f["val"]]
        if active_f: parts.append(f"{len(active_f)} filter{'s' if len(active_f)>1 else ''} applied")
        if sort_col != "— none —": parts.append(f"sorted by {sort_col}")
        if pinned: parts.append(f"{pinned} row{'s' if pinned>1 else ''} pinned")
        if parts: st.caption("View: " + " · ".join(parts) + f" · {len(view_df):,} rows")
        st.dataframe(apply_formats(view_df, formats), use_container_width=True, hide_index=True)
        c1, c2 = st.columns(2)
        with c1:
            st.download_button("⬇ Download CSV", view_df.to_csv(index=False).encode("utf-8"), f"{selected_name} (custom).csv", "text/csv", use_container_width=True)
        with c2:
            buf = io.BytesIO()
            with pd.ExcelWriter(buf, engine="openpyxl") as w: view_df.to_excel(w, index=False, sheet_name="Report")
            st.download_button("⬇ Download Excel", buf.getvalue(), f"{selected_name} (custom).xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", use_container_width=True)

    with tab_explore:
        st.caption("Build charts and tables from the report data. Nothing saves — each session starts fresh.")
        explore_df = df_base.copy()
        for col in explore_df.columns:
            coerced = pd.to_numeric(explore_df[col], errors="coerce")
            if coerced.notna().sum() > len(explore_df) * 0.7:
                explore_df[col] = coerced
        html_content = build_explore_html(explore_df)
        components.html(html_content, height=720, scrolling=False)

else:
    st.info("Set your filters and click **Run Report**.")
